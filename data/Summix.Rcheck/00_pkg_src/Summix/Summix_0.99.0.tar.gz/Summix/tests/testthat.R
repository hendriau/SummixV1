library(testthat)
library(Summix)

test_check("Summix")
