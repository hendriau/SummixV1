library(testthat)
library(summix)

test_check("summix")
