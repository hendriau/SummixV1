# summix
Estimating ancestry structure and adjusting allele frequencies for heterogeneous populations in online genetic databases
